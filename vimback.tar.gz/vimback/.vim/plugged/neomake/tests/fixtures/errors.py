if not this or foo bar:
    meh
